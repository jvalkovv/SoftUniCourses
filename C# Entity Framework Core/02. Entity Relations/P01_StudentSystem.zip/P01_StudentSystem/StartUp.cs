﻿using Microsoft.EntityFrameworkCore;
using P01_StudentSystem.Data;
using P01_StudentSystem.Data.Models;
using P01_StudentSystem.Data.Models.Enums;

namespace P01_StudentSystem
{
    public class StartUp
    {
        public static void Main()
        {

        }
    }
}