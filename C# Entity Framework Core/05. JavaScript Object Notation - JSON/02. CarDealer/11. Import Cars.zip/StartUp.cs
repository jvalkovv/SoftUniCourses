﻿using AutoMapper;
using CarDealer.Data;
using CarDealer.DTOs.Import;
using CarDealer.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System.IO;
using Castle.Core.Internal;

namespace CarDealer
{
    public class StartUp
    {
        private static IMapper CreateMapper()
        {
            return new Mapper(new MapperConfiguration(conf =>
            {
                conf.AddProfile<CarDealerProfile>();
            }));
        }

        private static IContractResolver ConfigCamelCaseNaming()
        {
            return new DefaultContractResolver()
            {
                NamingStrategy = new CamelCaseNamingStrategy(false, true)
            };
        }
        public static void Main()
        {
            var db = new CarDealerContext();
            string inputJson = File.ReadAllText(@"../../../Datasets/cars.json");
            var result = ImportCars(db, inputJson);

            Console.WriteLine(result);
        }

        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            IMapper mapper = CreateMapper();

            List<ImportSupplierDto> importSupplierDtos = JsonConvert.DeserializeObject<List<ImportSupplierDto>>(inputJson);

            List<Supplier> suppliers = mapper.Map<List<Supplier>>(importSupplierDtos);

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count}.";
        }

        public static string ImportParts(CarDealerContext context, string inputJson)
        {

            IMapper mapper = CreateMapper();

            ImportPartDto[] importPartDtos = JsonConvert.DeserializeObject<ImportPartDto[]>(inputJson);

            ICollection<Part> validParts = new HashSet<Part>();

            foreach (var partDto in importPartDtos)
            {
                if (context.Suppliers.Any(s => s.Id == partDto.SupplierId) &&
                    context.Suppliers.Any(s => s.IsImporter == true))
                {
                    validParts.Add(mapper.Map<Part>(partDto));
                }
            }

            context.Parts.AddRange(validParts);
            context.SaveChanges();



            return $"Successfully imported {validParts.Count}.";
        }

        public static string ImportCars(CarDealerContext context, string inputJson)
        {
            IMapper mapper = CreateMapper();

            ImportCarDto[] importCars = JsonConvert.DeserializeObject<ImportCarDto[]>(inputJson);

            ICollection<Car> validCars = new HashSet<Car>();
            ICollection<PartCar> validPart = new HashSet<PartCar>();

            foreach (var carDtos in importCars)
            {
                Car car = mapper.Map<Car>(carDtos);
                validCars.Add(car);

                foreach (var partId in carDtos.PartId.Distinct())
                {
                    PartCar partCar = new PartCar()
                    {
                        Car = car,
                        PartId = partId
                    };
                    validPart.Add(partCar);
                }
            }

            context.Cars.AddRange(validCars);
            context.PartsCars.AddRange(validPart);
            context.SaveChanges();

            return $"Successfully imported {validCars.Count}.";
        }


    }
}