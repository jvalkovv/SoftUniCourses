﻿using AutoMapper;
using CarDealer.Data;
using CarDealer.DTOs.Import;
using CarDealer.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace CarDealer
{
    public class StartUp
    {
        private static IMapper CreateMapper()
        {
            return new Mapper(new MapperConfiguration(conf =>
            {
                conf.AddProfile<CarDealerProfile>();
            }));
        }

        private static IContractResolver ConfigCamelCaseNaming()
        {
            return new DefaultContractResolver()
            {
                NamingStrategy = new CamelCaseNamingStrategy(false, true)
            };
        }
        public static void Main()
        {
            var db = new CarDealerContext();
            string inputJson = File.ReadAllText(@"../../../Datasets/suppliers.json");

            string result = ImportSuppliers(db,inputJson);

            Console.WriteLine(result);
        }

        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            IMapper mapper = CreateMapper();

            List<ImportSupplierDto> importSupplierDtos = JsonConvert.DeserializeObject<List<ImportSupplierDto>>(inputJson);

            List<Supplier> suppliers = mapper.Map<List<Supplier>>(importSupplierDtos);

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count}.";
        }
    }
}