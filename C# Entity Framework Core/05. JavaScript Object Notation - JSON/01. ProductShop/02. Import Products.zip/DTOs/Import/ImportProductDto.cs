﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace ProductShop.DTOs.Import
{
    public class ImportProductDto
    {
        //"Name": "Care One Hemorrhoidal",
        //"Price": 932.18,
        //"SellerId": 25,
        //"BuyerId": 24

        [JsonProperty("Name")]
        public string Name { get; set; } = null!;

        [JsonProperty("Price")]
        public decimal Price { get; set; } 

        [JsonProperty("SellerId")]
        public int SellerId { get; set; } 

        [JsonProperty("BuyerId")]
        public int? BuyerId { get; set; }


    }
}
