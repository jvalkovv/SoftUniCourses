﻿using AutoMapper;
using ProductShop.Data;
using ProductShop.DTOs.Import;
using ProductShop.Models;
using static ProductShop.DTOs.Import.ImportUserDto;

namespace ProductShop
{
    public class StartUp
    {
        private static IMapper InitializeAutoMapper()
            => new Mapper(new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<ProductShopProfile>();
            }));
        public static void Main()
        {
            var db = new ProductShopContext();
            db.Database.EnsureCreated();

            string inputXML = File.ReadAllText(@"../../../Datasets/users.xml");
            var result = ImportUsers(db, inputXML);

            Console.WriteLine(result);

        }

        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            IMapper mapper = InitializeAutoMapper();

            XmlHelper xmlHelper = new XmlHelper();
            ImportUserDto[] usersDtos =
                xmlHelper.Deserialize<ImportUserDto[]>(inputXml, "Users");

            ICollection<User> validUsers = new HashSet<User>();

            foreach (var u in usersDtos)
            {
                if (string.IsNullOrEmpty(u.FirstName) || string.IsNullOrEmpty(u.LastName))
                {
                    continue;
                }
                User users = mapper.Map<User>(u);

                validUsers.Add(users);
            }

            context.Users.AddRange(validUsers);
            context.SaveChanges();

            return $"Successfully imported {validUsers.Count}";
        }

    }
}