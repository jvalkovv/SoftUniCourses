﻿namespace CarDealer.Data
{
    
    public class Configuration
    {

        public const string ConnectionString =
            @"Server=.;Database=CarDealer;Trusted_Connection=True;";
    }
}
