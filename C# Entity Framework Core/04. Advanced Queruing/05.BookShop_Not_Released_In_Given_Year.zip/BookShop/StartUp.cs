﻿using System.Text;
using BookShop.Models.Enums;
using BookShop.Models;
using Microsoft.EntityFrameworkCore;

namespace BookShop
{
    using BookShop.Models;
    using Data;
    using Initializer;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            DbInitializer.ResetDatabase(db);

            //string input = Console.ReadLine();

            //var result = GetBooksByAgeRestriction(db, input);

            //var result = GetGoldenBooks(db);

            //var result = GetBooksByPrice(db);

            int givenYear = int.Parse(Console.ReadLine());
            var result = GetBooksNotReleasedIn(db, givenYear);
            Console.WriteLine(result);


        }

        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {

            StringBuilder sb = new StringBuilder();


            var allBook = context.Books.ToList()
                .Where(b => b.AgeRestriction.ToString().ToLower() == command.ToLower())
                .Select(b => new
                {
                    BookTitle = b.Title
                })
                .OrderBy(b => b.BookTitle)
                .ToList();


            foreach (var b in allBook)
            {
                sb.AppendLine(b.BookTitle);
            }


            return sb.ToString().TrimEnd();
        }

        public static string GetGoldenBooks(BookShopContext context)
        {
            StringBuilder sb = new StringBuilder();

            var goldenBook = context.Books
                .ToList().Where(ge => ge.EditionType == EditionType.Gold)
                .Select(t => new
                {
                    BookTitle = t.Title,
                    BookID = t.BookId,
                    Copies = t.Copies
                })
                .Where(t => t.Copies < MagicNumbers.CopiesNumberLessThan5000)
                .OrderBy(b => b.BookID)
                .ToList();


            foreach (var b in goldenBook)
            {
                sb.AppendLine(b.BookTitle);
            }


            return sb.ToString().TrimEnd();

        }

        public static string GetBooksByPrice(BookShopContext context)
        {
            StringBuilder sb = new StringBuilder();


            var books = context.Books
                .ToList()
                .Where(b => b.Price > MagicNumbers.PriceMoreThan40)
                .Select(t => new
                {
                    TitleName = t.Title,
                    BookPrice = t.Price
                })
                .OrderByDescending(p => p.BookPrice)
                .ToList();


            foreach (var b in books)
            {
                sb.AppendLine($"{b.TitleName} - ${b.BookPrice:f2}");
            }

            return sb.ToString().TrimEnd();
        }

        public static string GetBooksNotReleasedIn(BookShopContext context, int year)
        {
            StringBuilder sb = new StringBuilder();

            var books = context.Books
                .ToList()
                .Where(b => b.ReleaseDate.Value.Year != year)
                .Select(b => new
                {
                    BookID = b.BookId,
                    BookTitle = b.Title
                })
                .OrderBy(b => b.BookID)
                .ToList();


            foreach (var b in books)
            {
                sb.AppendLine($"{b.BookTitle}");
            }

            return sb.ToString().TrimEnd();
        }

    }
}


