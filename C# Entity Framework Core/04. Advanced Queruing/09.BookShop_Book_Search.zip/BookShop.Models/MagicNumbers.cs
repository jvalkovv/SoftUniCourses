﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookShop.Models
{
    public class MagicNumbers
    {
        public const int CopiesNumberLessThan5000 = 5000;

        public const int PriceMoreThan40 = 40;
    }
}
