﻿using System.Text;
using BookShop.Models.Enums;

namespace BookShop
{
    using Data;
    using Initializer;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            DbInitializer.ResetDatabase(db);

            string input = Console.ReadLine();

            var result = GetBooksByAgeRestriction(db, input);

            Console.WriteLine(result);

        }

        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {

            StringBuilder sb = new StringBuilder();


            var allBook = context.Books.ToList()
                .Where(b => b.AgeRestriction.ToString().ToLower() == command.ToLower())
                .Select(b => new
                {
                    BookTitle = b.Title
                })
                .OrderBy(b => b.BookTitle)
                .ToList();


            foreach (var b in allBook)
            {
                sb.AppendLine(b.BookTitle);
            }


            return sb.ToString().TrimEnd();
        }
    }
}


