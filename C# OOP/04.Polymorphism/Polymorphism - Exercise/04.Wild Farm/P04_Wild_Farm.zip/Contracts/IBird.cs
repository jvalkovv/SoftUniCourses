﻿namespace WildFarm.Contracts
{
    internal interface IBird
    {
        double WingSize { get; }
    }
}
