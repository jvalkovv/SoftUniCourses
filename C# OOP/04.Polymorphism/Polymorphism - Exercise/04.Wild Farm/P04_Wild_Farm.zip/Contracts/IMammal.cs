﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Contracts
{
    internal interface IMammal
    {
        string LivingRegion { get; }
    }
}
